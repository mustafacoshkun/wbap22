<html><head></head>
<!-- file4.php -->
<body>

<?php
$myFile = "testFile.txt";
$fh = fopen($myFile, "a") or die("can't open file");
$stringData = "New Stuff 1\n";
fwrite($fh, $stringData);
$stringData = "New Stuff 2\n";
fwrite($fh, $stringData);
fclose($fh);
?>

<?php
$lines = file($myFile);
foreach ($lines as $l_num => $line) 
{
 echo "Line #{$l_num}: ".$line."<br/>";
}
?>


</body>
</html>
