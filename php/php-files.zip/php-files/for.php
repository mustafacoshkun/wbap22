<html><head></head>
<!-- for.php -->
<body>

<?php
for ($i=1; $i<=5; $i++)
{
echo "Hello World!<br /> \n";
}
?>

<br />

<?php
$a_array = array(1, 2, 3, 4);
foreach ($a_array as $value) 
{
   $value = $value * 2;
   echo "$value <br/> \n";
}
?>

</br>

<?php 
$a_array=array("a","b","c");
foreach ($a_array as $key=>$value)
{
  echo $key." = " . $value."</br>\n";
}
?>

</body>
</html>
