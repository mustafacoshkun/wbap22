<html><head></head>
<!-- if-cond.php COMP519 -->
<body>

<?php
$d=date("D");
echo $d, "<br/>";
if ($d=="Fri")
     echo "Have a nice weekend! <br/>"; 
else
     echo "Have a nice day! <br/>"; 

$x=10;
if ($x==10)
{
     echo "Hello<br />"; 
     echo "Good morning<br />";
}

?>

</body>
</html>

