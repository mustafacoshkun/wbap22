<html>
<head><title>Date example</title></head>
<body>

<?php
//Prints something like: Monday
echo "<h3>", date("l"), "</h3> \n";

//Like: Monday 15th of January 2003 05:51:38 AM
echo "<h3>", date("l jS \of F Y h:i:s A"), "</h3> \n";

//Like: Monday the 15th
echo "<h3>", date("l \\t\h\e jS"), "</h3> \n";
?>

</body>
</html>
