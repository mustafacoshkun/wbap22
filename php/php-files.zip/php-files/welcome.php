<html>
<!-- welcome.php -->
<body>
<p>
Welcome <?php echo $_POST["name"]."."; ?> <br />
You are <?php echo $_POST["age"]; ?> years old!
</p>
</body>
</html>
