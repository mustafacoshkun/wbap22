<?php

phpinfo();

?>

 
