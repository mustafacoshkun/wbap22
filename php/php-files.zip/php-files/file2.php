<html><head></head>
<!-- file2.php -->
<body>

<?php
$myFile = "welcome.txt";
$fh = fopen($myFile, 'r');
$theData = fgets($fh);
fclose($fh);
echo $theData;
?>

</body>
</html>
