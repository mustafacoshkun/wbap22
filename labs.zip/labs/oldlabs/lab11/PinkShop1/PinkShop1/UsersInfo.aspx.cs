﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace PinkShop1
{
    public partial class UsersInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void add_Click(object sender, EventArgs e)
        {
            
        }

        protected void Add_Click1(object sender, EventArgs e)
        {
            if (IsValid)
            {
                var parameters = AccessDataSource1.InsertParameters;
                parameters["username"].DefaultValue = newUserName.Text;
                parameters["email"].DefaultValue = newEmail.Text;
            }
            try
            {
                
                AccessDataSource1.Insert();
                newUserName.Text = "";
                newEmail.Text = "";
                //GridView1.DataBind();
            }
            catch (Exception ex)
            {
                lbl_error.Text = ex.Message;

            }
        }
    }
}