﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace PinkShop1
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lb_register_Click(object sender, EventArgs e)
        {
            string connDB = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\ACS\\Desktop\\UserDB.accdb";
            string pass = txt_password.Text;
            string password = FormsAuthentication.HashPasswordForStoringInConfigFile(pass, "md5");
            string username = txt_name.Text;
            using (OleDbConnection con = new OleDbConnection(connDB))
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into Users ([username],[password]) values (@un,@pw)";
                cmd.Parameters.AddWithValue("@un", username);
                cmd.Parameters.AddWithValue("@pw", password);
                cmd.Connection = con;

                int rowsAffected = 0;

                try
                {
                    con.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch (Exception ex)
                {
                    lbl_output.Text = "Hata" + ex.Message;
                    return;
                }
                finally
                {
                    if (con.State != ConnectionState.Closed)
                        con.Close();
                }
                if (rowsAffected == 1)
                    lbl_output.Text = "Kayıt edildi";
                else
                    lbl_output.Text = "Kayıt edilmedi";


            }
        }

        protected void submit_btn_Click(object sender, EventArgs e)
        {
            string connDB= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\ACS\\Desktop\\UserDB.accdb";

            string pass = txt_password.Text;
            string password = FormsAuthentication.HashPasswordForStoringInConfigFile(pass, "md5");

            string username = txt_name.Text;

            using (OleDbConnection con = new OleDbConnection(connDB))
            {
                OleDbCommand cmd = new OleDbCommand("Select * from Users where username='" + username + "'  and  password='" + password + "'", con);
                con.Open();

                OleDbDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Session["islogin"] = true;
                    Session["UserName"] = username;
                    Response.Redirect("MyPage.aspx");

                }else
                {
                    lbl_output.Text = "Parola veya kullanıcı adı yanlış";
                }
                dr.Close();
                con.Close();

            }

        }
    }
}