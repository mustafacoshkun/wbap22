﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication9
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            lbl_time.Text = DateTime.Now.ToString("hh:mm:ss");
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            Validate();

            if (IsValid)
            {
                string name = txt_name.Text;
                string email = txt_email.Text;
                string phone = txt_phone.Text;

                lbl_output.Text = String.Format("Name: {0}{1} Email: {2}{1} Phone:{3}", name, "<br/>", email, phone);
                lbl_output.Visible = true;
            }
        }

        protected void btn_output2_Click(object sender, EventArgs e)
        {
            lbl_output2.Visible = true;

            if (rbl_programs.SelectedItem != null)
            {
                lbl_output2.Text = "You selected " + rbl_programs.SelectedItem.Text;
            }
            else
                lbl_output2.Text = "You did not select";
        }
    }
}