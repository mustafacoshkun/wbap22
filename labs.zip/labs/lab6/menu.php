<ul id="menulist">
    <li class="menuitem"><a href="index.php">Home Page</a> </li>
    <li class="menuitem"><a href="syllabus.html">Syllabus</a> </li>
    <li class="menuitem"><a href="#">Lecture Notes</a> </li>
    <li class="menuitem"><a href="#">Grades</a> </li>
    <li class="menuitem"><a href="#">Lab Examples</a> </li>
    <li class="menuitem"><a href="#">Assignment</a> </li>
    <li class="menuitem"><a href="logout.php">Logout</a> </li>
</ul>
