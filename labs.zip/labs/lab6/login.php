<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MIS 233 | Lab 2</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
if(isset($_POST["submit"]))
{
    $uname= $_POST["uname"];
    $upass= $_POST["upass"];
    $db = new mysqli("127.0.0.1","root","","mis233");
    $result=$db ->query("select * from users where uname='$uname' and upassword='$upass'");
    if($result->num_rows ==0)
    {
        echo "username or password is wrong!!!";
    }else
    {
        $_SESSION["uname"]=$uname;
        $row=$result->fetch_row();
        $_SESSION["ufullname"]=$row[2];
        header("Location: userindex.php");
    }
}
?>
    <div id="top">
        <h1>MIS 233.01</h1>
        <p>Web Based Application Programming</p>
    </div>
    <div class="wrapper">
        <div id="menubar">
            <?php
                include "menu.php";
            ?>
        </div>
        <div id="main">
            <h1>LOGIN FORM</h1>
            <form action="login.php" method="post">
                User Name: <input type="text" name="uname"><br>
                User Password: <input type="password" name="upass"><br>
                <input type="submit" name="submit" value="SEND">

            </form>

        </div>
        <div id="ann">
            <h2>Navigation</h2>
            <p><a href="login.php">Login</a></p>
            <p><a href="register.php">Register</a></p>
        </div>
    </div>
    <div id="bottom">
        <table id="table1">
            <tr>
                <td class="cellitem">Company</td>
                <td class="cellitem">About Us</td>
                <td class="cellitem">Mission</td>
                <td class="cellitem">Comment</td>
            </tr>
        </table>
        <p>MIS 233.01 - WEB BASED APPLICATION PROGRAMMING</p>
    </div>

</body>
</html>
