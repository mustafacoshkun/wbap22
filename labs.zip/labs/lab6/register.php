<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MIS 233 | Lab 2</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
if(isset($_POST["submit"]))
{
    $uname=$_POST["uname"];
    $ufullname=$_POST["ufullname"];
    $upass1=$_POST["upass1"];
    $upass2=$_POST["upass2"];
    if($upass1!=$upass2)
    {
        echo "passwords are not matching";
    }else{
        $db = new mysqli("127.0.0.1","root","","mis233");
        $result=$db->query("INSERT INTO users (uname,ufullname,upassword) VALUES ('$uname','$ufullname','$upass1')");
        if($result)
        {
            echo "your user with the name $uname is created. You may login right now!";
        }else
        {
            echo "something happen wrong. Please try again";
        }
    }
}
?>
    <div id="top">
        <h1>MIS 233.01</h1>
        <p>Web Based Application Programming</p>
    </div>
    <div class="wrapper">
        <div id="menubar">
            <?php
                include "menu.php";
            ?>
        </div>
        <div id="main">
            <h1>MIS 233.01 Home Page</h1>
            <form action="register.php" method="post">
                User Name: <input type="text" name="uname"><br>
                User Full Name: <input type="text" name="ufullname"><br>
                User Password: <input type="text" name="upass1"><br>
                User Password (Again): <input type="text" name="upass2"><br>
                <input type="submit" name="submit" value="REGISTER">
            </form>
        </div>
        <div id="ann">
            <h2>Navigation</h2>
            <p><a href="login.php">Login</a></p>
            <p><a href="register.php">Register</a></p>
        </div>
    </div>
    <div id="bottom">
        <table id="table1">
            <tr>
                <td class="cellitem">Company</td>
                <td class="cellitem">About Us</td>
                <td class="cellitem">Mission</td>
                <td class="cellitem">Comment</td>
            </tr>
        </table>
        <p>MIS 233.01 - WEB BASED APPLICATION PROGRAMMING</p>
    </div>

</body>
</html>
