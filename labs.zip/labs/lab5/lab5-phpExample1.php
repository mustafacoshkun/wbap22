<!DOCTYPE html>
<html>
<head>
    <title>FORM SUBMISSION</title>
</head>
<body>
    <?php
        if(!isset($_POST["submit"])) //if the submit objects sent value is NULL
            //if my client hasnt been send the form yet
        {
    ?>
                <form method="get" action="index.php">
                   <fieldset>
                       <legend>Registration Form</legend>
                       <label for="uname">Name:</label>
                       <input type="text" id="uname" name="username">
                       <br>
                       <label for="usname">Surname:</label>
                       <input type="text" id="usname" name="usersurname">
                       <br>
                       <label for="utel">Tel Number:</label>
                       <input type="tel" id="utel" name="usertel" placeholder="(###) ###-####">
                        <br>
                       <label for="usport">Your favorite team:</label>
                        <select id="usport" name="usersport">
                            <option value="fb">Fenerbahce</option>
                            <option value="bjk">Besiktas</option>
                            <option value="gs" selected>Galatasaray</option>
                            <option value="-1">other</option>
                        </select>
                       <br>
                       <label for="uage">Your age</label>
                       <select name="userage" id="uage">,
                           <?php
                                for($i=8;$i<=40;$i++)
                                {
                                    echo "<option>$i</option>";
                                }
                           ?>
                       </select>

                       <br>
                       <label for="ugender">Gender</label>
                       <input type="radio" id="ugender" name="usergender" value="m">Male
                       <input type="radio" id="ugender" name="usergender" value="f">Female
                       <input type="radio" id="ugender" name="usergender" value="na" checked>Not want to say
                        <br>
                       <input type="reset" value="RESET FORM">
                       <input type="submit" name="submit" value="SEND FORM">
                   </fieldset>
                </form>
        <?php
        }else{ //if the client sent the form
            echo "Hello " . $_POST["username"] . " " . $_POST["usersurname"] . "<br>";
            echo "your information given in the form are:<br>";
            echo "Tel:". $_POST["usertel"];
            $a=$_POST["usersport"];
            switch ($a)
            {
                case "gs": echo "CIMBOMBOM"; break;
                case "bjk": echo "BESIKTASK"; break;
                case "fb": echo "ALLAH BAŞKA DERT VERMESIN"; break;
                default: echo "I dont know why you dot like football";
            }
        }
        ?>
</body>
</html>