function showarray(theArray){
    var content="<h1>Content of the array</h1>";
    for(var i=0;i<theArray.length;i++)
    {
        content+=theArray[i]+"<br>";
    }
    document.getElementById("output1").innerHTML=content;
}
var n1=new Array(5);
var n2=new Array(8);
for(var i=0;i<n1.length;i++)
    n1[i]=i*2; //n1[0]=0,n1[1]=2,n1[2]=4
for(var i=0;i<n2.length;i++)
    n2[i]=i; //n2[0]=0,n2[1]=1,n2[2]=2
function makeItUpper(){
    var x=document.getElementById("name");
    x.value=x.value.toUpperCase();
}