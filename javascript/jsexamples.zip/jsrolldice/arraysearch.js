function arraySearch()
{
    var a=["a","b","c","d"];
    var result=a.indexOf("c",-3);
    document.getElementById("output").innerText=result;
}