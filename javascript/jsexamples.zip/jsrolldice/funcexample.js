function sortArray()
{
    var a=[10,1,12,3,2,32,14,5,99];
    a.sort((a,b)=>b-a);
    document.getElementById("output").innerText=a.join(",");
}
